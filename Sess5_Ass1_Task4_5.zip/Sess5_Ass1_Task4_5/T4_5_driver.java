import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class T4_5_driver extends Configured {
	
	// Driver function to execute the Map reduce job
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		final int NUM_REDUCER_TASKS = 4;
		
		//Creating Configuration object and Job Object
		Configuration conf = new Configuration();
		Job job =Job.getInstance(conf, "TV Sales report with 4 reducers and combiner ");
		
		// Setting Main class, Map, reduce and Partitioner and Combiner class 
		job.setJarByClass(T4_5_driver.class);
		job.setMapperClass(T4_5_mapper.class);
		job.setCombinerClass(T4_5_reducer.class);
		job.setReducerClass(T4_5_reducer.class);
		job.setPartitionerClass(T4_5_partitioner.class);
		
		// Setting Number of Reducer tasks to 4
		job.setNumReduceTasks(NUM_REDUCER_TASKS);
		
		// Setting Map Output Key, value type
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		//Setting Reducer Output Key, value type
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		//Setting Input and Output Directory
		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		
		//System.exit() will return 0 on successful execution, else -1
		System.exit(job.waitForCompletion(true) ? 0 : -1);

	}

}
