import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class T4_5_partitioner extends Partitioner<Text,IntWritable>{

	@Override
	public int getPartition(Text key, IntWritable value, int num_reducer_tasks) {
		
		int ret_val = 0;
		String temp_key = key.toString();
		
		// Check if the key starts with A-F
		// regex (?i)^[A-F].*$ --> Case Insensitive, 
		// Start of line with A-F followed by 0 or more characters 
		// till end of string
		if (temp_key.matches("(?i)^[A-F].*$"))
		{
			ret_val = 0;
		}
		// Check if the key starts with G-L
		if(temp_key.matches("(?i)^[G-L].*$"))
		{
			ret_val =  1;
		}
		// Check if the key starts with M-R
		if(temp_key.matches("(?i)^[M-R].*$"))
		{
			ret_val =  2;
		}
		// Check if the key starts with S-Z
		if (temp_key.matches("(?i)^[S-Z].*$"))
		{
			ret_val =  3;
		}
		
		return ret_val;		

	}


}
